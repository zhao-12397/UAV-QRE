# -*- coding: utf-8 -*-
"""Q15 定向验证：perceived() 中 qB 平移的不一致是设计选择还是漏接"""
import json,sys,copy,numpy as np
P=r"G:\暑假文件夹\无人机\仿真实验代码包\FC30_QRE_剩余窗口_v6_代码与重算结果-03\FC30_QRE_剩余窗口_v6"
sys.path.insert(0,P); import simulate_fc30 as m
c=json.loads(open(P+r"\params_fc30_v3.json",encoding="utf-8").read())
c['implementation']=json.loads(open(P+r"\model_supplement.json",encoding="utf-8").read())
s=m.scenario(c);Z=np.random.default_rng(20261007).standard_normal((1024,3))

print("="*82)
print("Q15-a  A 的偏置语义：A 感知 B 有偏，B 自身没有偏")
print("="*82)
cc=copy.deepcopy(c)
cc['information_structure']['asymmetry_method_check']['A_rel_pos_bias_m']['value']=[0.,4.,0.]
for pl in 'AB':
    p=m.perceived(cc,s,pl,True)
    print(f"  player={pl}: dpB={p['pB']-s['pB']}  dqB={p['qB']-s['qB']}")
print("""
  语义分析:
    qB = B 的汇入点 = pB(0) + V*span*unit(hB)
    若 A 相信 B 的位置有偏 pb，则 A 重建的 B 航线整体平移 pb，
    A 重建的 qB 应 = (pB+pb) + V*span*unit(hB+vb) ≈ qB + pb
  → 代码中 qB 的平移条件写死为 player=='B'，A 感知有偏时 qB 不动
  → 这在语义上不成立：A 的感知偏置应同样平移其重建的 qB
  → 结论：属于实现不一致（漏接），应修复""")

print()
print("="*82)
print("Q15-b  修复方案验证：qB 平移条件改为按 observer 而非被观测方")
print("="*82)
def perceived_fixed(c,s,player,asym=False):
    out=copy.deepcopy(s)
    if asym:
        pb=m.value(c,'information_structure','asymmetry_method_check',player+'_rel_pos_bias_m')
        vb=m.value(c,'information_structure','asymmetry_method_check',player+'_rel_vel_bias_mps')
    else:
        bias=m.value(c,'information_structure','perception_bias_baseline')
        pb=bias[player+'_rel_pos_bias_m'];vb=bias[player+'_rel_vel_bias_mps']
    obs=float(m.value(c,'information_structure','observation_delay_s'))
    out['pA']-=obs*s['vA'];out['pB']-=obs*s['vB']
    out['pB']+=np.array(pb);out['vB']+=np.array(vb)
    out['hB']=np.arctan2(out['vB'][1],out['vB'][0])
    # FIX: observer 的位置感知偏置同时平移其重建的对侧汇入点
    out['qB']+=np.array(pb)
    return out
for tag,cfg in [("A偏置",'A'),("B偏置",'B')]:
    c2=copy.deepcopy(c)
    c2['information_structure']['asymmetry_method_check'][cfg+'_rel_pos_bias_m']['value']=[0.,4.,0.]
    print(f"  {tag} [0,4,0]:")
    for pl in 'AB':
        old=m.perceived(c2,s,pl,True); new=perceived_fixed(c2,s,pl,True)
        print(f"    player={pl}  旧:dpB={old['pB']-s['pB']} dqB={old['qB']-s['qB']}   "
              f"新:dpB={new['pB']-s['pB']} dqB={new['qB']-s['qB']}")

print()
print("="*82)
print("Q15-c  修复对非对称工况结论的影响（是否只是平移、还是改变排序）")
print("="*82)
print("现状（原代码）：B_rel_pos_bias=[0,4,0] → 只有 B 感知有偏")
for t in [10.0,25.5]:
    e=m.outcomes(c,s if False else m.at_time(s,t),Z,asym=True)
    from scipy.special import expit
    A={k:v['U'] for k,v in e['A'].items()};B={k:v['U'] for k,v in e['B'].items()}
    FA=lambda y: float(expit(4*(y*(A['Y,Y']-A['N,Y'])+(1-y)*(A['Y,N']-A['N,N']))))
    FB=lambda x: float(expit(4*(x*(B['Y,Y']-B['Y,N'])+(1-x)*(B['N,Y']-B['N,N']))))
    f=lambda x: FA(FB(x))-x
    import scipy.optimize as so
    xx=np.linspace(0,1,2001);ff=[f(x) for x in xx];roots=[]
    for k in range(len(xx)-1):
        if ff[k]*ff[k+1]<0:roots.append(so.brentq(f,xx[k],xx[k+1],xtol=1e-14))
    r0=min(roots,key=lambda x:abs(x-0.8))
    print(f"  t={t:5.1f}  Pcol_NN: A={e['A']['N,N']['Pcol_max']:.6f} B={e['B']['N,N']['Pcol_max']:.6f}"
          f"  → pA_Y={r0:.5f} pB_Y={FB(r0):.5f}")

print()
print("="*82)
print("Q15-d  结论：修复属于'语义补全'还是'改变模型'")
print("="*82)
print("""  判定依据:
  1. qB 的定义是 pB(0) + V*span*unit(hB)，与 pB、hB 严格绑定
  2. 代码已同步更新 hB = arctan2(vB)，即已处理"方向偏置→航向偏置"
  3. 但位置偏置 pb 对 pB 生效、对 qB 不生效 → 同一组变量处理不一致
  4. 若认为"qB 应保持客观真值"，则 pB 也不应偏；两者必须同一口径

  → 两种自洽口径:
     (i)  全客观: pB 不偏, qB 不偏 → 则 perceived() 中的 pb/vb 应整体移除
     (ii) 全主观: pB 偏, qB 同步偏 → 当前代码部分实现，需补全
  现有代码是 (ii) 的不完整版本 → 判定为实现不完整，按 (ii) 补全""")