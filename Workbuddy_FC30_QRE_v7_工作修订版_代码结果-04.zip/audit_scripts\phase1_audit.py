# -*- coding: utf-8 -*-
"""阶段1核查：公式—代码对应、感知输入、四策略轨迹、物理概率、异常定位"""
import json,sys,copy,numpy as np
from scipy.special import expit
P=r"G:\暑假文件夹\无人机\仿真实验代码包\FC30_QRE_剩余窗口_v6_代码与重算结果-03\FC30_QRE_剩余窗口_v6"
sys.path.insert(0,P); import simulate_fc30 as m
c=json.loads(open(P+r"\params_fc30_v3.json",encoding="utf-8").read())
c['implementation']=json.loads(open(P+r"\model_supplement.json",encoding="utf-8").read())
s=m.scenario(c); Z=np.random.default_rng(20261007).standard_normal((1024,3))

print("#"*80)
print("# A. 公式—代码对应关系：params 声明 vs 代码实际")
print("#"*80)
checks=[
 ("utility.formula 声明", c['utility']['formula']['value']),
 ("model_supplement 声明", c['implementation']['utility_formula_source']),
 ("代码实际 Cs", "min(P/Pref,1)  -> 第248行"),
]
for k,v in checks: print(f"  {k}:\n     {v}")
print()
print("  dynamic_decision.aggregation_rule 声明:")
print("     ",c['dynamic_decision']['aggregation_rule']['value'][:120],"...")
print("  primary_risk_reporting 声明:")
for k,v in c['dynamic_decision']['primary_risk_reporting']['value'].items(): print(f"     {k}: {v}")
print()
print("  >> 差异: params.utility.formula 写 Pcol/(Pcol+Pref)（连续），代码写 min(P/Pref,1)（截断）")
print("  >> params.primary_risk_reporting 声明主结果含 instantaneous_joint_non_yield 等四项，")
print("     代码 summary.json 只输出 P_three_stage_* 三项 → 声明与实现不一致")
print()
print("  被 model_supplement 标为 obsolete 但代码实际未使用的字段核查:")
obs=c['implementation']['obsolete_numeric_fields_retained_only']
for f in obs: print(f"     - {f}")
print()
print("  未被任何代码引用的 params 字段（抽查关键项）:")
for fld in ['obstacle_avoidance_reference.radar_range_m','aircraft.max_pitch_deg',
            'collision_probability.candidate_time_count','numerics.make_plots',
            'uncertainty.velocity_sigma_sweep_mps','dynamic_decision.kappa_1']:
    grp,key=fld.split('.')
    v=c[grp][key]
    src=json.dumps(c,ensure_ascii=False)
    tag='在params中' if key in src else '?'
    print(f"     - {fld} = {v if not isinstance(v,dict) else v.get('value')}")

print()
print("#"*80)
print("# B. 感知输入：perceived() 语义一致性")
print("#"*80)
cc=copy.deepcopy(c)
cc['information_structure']['asymmetry_method_check']['B_rel_pos_bias_m']['value']=[0.,4.,0.]
print("设 B_rel_pos_bias_m = [0,4,0]（非对称工况）")
for pl in 'AB':
    pst=m.perceived(cc,s,pl,True)
    print(f"\n  player={pl}:")
    print(f"     pB  偏移 = {pst['pB']-s['pB']}")
    print(f"     pA  偏移 = {pst['pA']-s['pA']}")
    print(f"     qB  偏移 = {pst['qB']-s['qB']}")
    print(f"     qA  偏移 = {pst['qA']-s['qA']}")
print()
print("  >> 核查结论：")
print("     player='A' 时：pb 来自 A_rel_pos_bias_m，加到 pB（=A对B位置的感知偏置），qB 未加")
print("     player='B' 时：pb 来自 B_rel_pos_bias_m，同样加到 pB（=B自身位置），qB 加了同样的 pb")
print("     两分支处理不一致：A的偏置不加qB，B的偏置加qB")
print("     语义上 qB 是 B 的汇入点；A 感知 B 位置有偏时，重建的 qB 也应随之偏，")
print("     但代码只在 player=='B' 时才平移 qB → 疑似漏接（Q15 待修）")
print()
print("  验证该不对称是否影响结论:")
for pl in 'AB':
    pst=m.perceived(cc,s,pl,True)
    r=m.trajectory(cc,pst,'N,N')
    p=m.probability(cc,r,0.1,0.,Z)[0]
    print(f"     player={pl} 看到NN 的 Pcol = {p:.6f}  min_q_collision={r['min_q_collision']:.4f}")

print()
print("#"*80)
print("# C. 四策略完整轨迹核查")
print("#"*80)
print("逐策略检查：到达、汇入、时长、恢复完成、最小间距")
for t in [12.0,25.5,28.1]:
    st=m.at_time(s,t)
    print(f"\n  t={t}s")
    print(f"  {'pair':>6} | {'recov_t':>8} {'rejoined':>9} | {'arrA':>8} {'arrB':>8} {'extraA':>9} {'end_errA':>10}")
    for pr in m.PAIRS:
        r=m.trajectory(c,st,pr); mt=r['metrics']
        ea=mt['A']['extra_length_m']
        print(f"  {pr:>6} | {str(r['recovery_time_s']):>8} {str(r['recovery_completed']):>9} | "
              f"{mt['A']['arrival_time_s']:8.2f} {mt['B']['arrival_time_s']:8.2f} "
              f"{('%.3f'%ea) if ea is not None else 'None':>9} "
              f"{('%.2e'%mt['A']['endpoint_error_m']) if mt['A']['endpoint_error_m'] is not None else 'None':>10}")
print()
print("  >> 关键：Y 策略若 recovery_time is None → extra=None → C_length=C_smooth=1.0")
print("     这表示'机动不可行'被编码成最大效率惩罚，而非安全惩罚。核对语义是否合理")

print()
print("#"*80)
print("# D. 物理概率计算核查")
print("#"*80)
st=m.at_time(s,20.0); r=m.trajectory(c,st,'N,N')
axes_coll=np.array(m.value(c,'geometry','combined_collision_half_axes_m'))
safe=axes_coll+np.array(c['implementation']['safety_margin_m'])
print(f"  碰撞椭球半轴 axes   = {axes_coll}")
print(f"  安全半轴 safe        = {safe}")
print(f"  safety_margin_m      = {c['implementation']['safety_margin_m']}  → 当前两者相同")
print(f"  probability() 用的是  = axes（碰撞椭球）")
print(f"  search_boundary 用的是 = safe")
print(f"  >> 在 margin=0 时两者一致；一旦设 margin>0，概率判据与几何判据口径将不同")
print()
H=m.value(c,'collision_probability','prediction_horizon_s')
print(f"  预测窗 H={H}s；trajectory 的 times 上限 = max(H, max arrival_time)")
for pr in m.PAIRS:
    rr=m.trajectory(c,st,pr)
    print(f"     {pr}: times上限={rr['times'][-1]:.2f}s  arrival_max={max(x['arrival_time_s'] for x in rr['metrics'].values()):.2f}s")
print(f"  >> probability() 只取 times<=H；min_q_safe 取全时程 → 概率判据只看前{H}s，几何判据看全程")

print()
print("#"*80)
print("# E. 现有异常定位")
print("#"*80)
print("E1. delay 为全局参数，无法分机设置")
print(f"     delay.execution_delay_baseline_s = {m.value(c,'delay','execution_delay_baseline_s')}")
print(f"     trajectory() 第129行直接读取，无A/B区分 → 需新增 A/B 两字段")
print()
print("E2. N,N 组合的时长被当作'到达汇入点'，但N策略本就不机动")
st2=m.at_time(s,12.0); rn=m.trajectory(c,st2,'N,N')
print(f"     N,N arrival_time = {rn['metrics']['A']['arrival_time_s']:.2f}s (= L0/V = {rn['metrics']['A']['baseline_length_m']:.1f}/{m.value(c,'aircraft','cruise_speed_mps')})")
print(f"     这是'飞到汇入点'的时间，但N策略下无机动，时间仅用于截断轨迹长度")
print()
print("E3. 汇入点 q 由 T+recovery_tail+2*turn 决定，与 t 无关 → L0 随 t 收缩已核实")
q=m.value(c,'scenario','baseline_target_tcpa_s')+m.value(c,'yield_action','recovery_tail_s')+2*m.value(c,'yield_action','baseline_heading_change_deg')/m.value(c,'yield_action','baseline_turn_rate_degps')
print(f"     span = TCPA + recovery_tail + 2*turn = {m.value(c,'scenario','baseline_target_tcpa_s')}+{m.value(c,'yield_action','recovery_tail_s')}+2*{m.value(c,'yield_action','baseline_heading_change_deg')}/{m.value(c,'yield_action','baseline_turn_rate_degps')} = {q:.1f}s")
print(f"     qA = pA(0) + V*span*unit(hA) → 固定空间点，两机各在自身航线上")
print()
print("E4. Y,N 与 Y,Y 的 C_length 大小关系（口径 Q6 待确认）")
for t in [12.0,20.0,25.5]:
    e=m.outcomes(c,m.at_time(s,t),Z)
    print(f"     t={t:5.1f}  Ce_YY={e['A']['Y,Y']['C_efficiency']:.5f}  Ce_YN={e['A']['Y,N']['C_efficiency']:.5f}  "
          f"{'Ce_YY<Ce_YN' if e['A']['Y,Y']['C_efficiency']<e['A']['Y,N']['C_efficiency'] else 'Ce_YY>=Ce_YN'}")
print("     >> 每个组合各用各自轨迹的 L0 作分母，非共同基准")